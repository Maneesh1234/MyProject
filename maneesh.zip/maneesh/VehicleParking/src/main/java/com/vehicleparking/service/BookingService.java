package com.vehicleparking.service;


import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.vehicleparking.model.Booking;
import com.vehicleparking.model.ParkingSpot;
import com.vehicleparking.model.VehicleType;
import com.vehicleparking.repository.BookingRepository;
import com.vehicleparking.repository.ParkingSpotRepository;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {
    private final BookingRepository bookingRepository;
    private final ParkingSpotRepository parkingSpotRepository;

    public BookingService(BookingRepository bookingRepository, ParkingSpotRepository parkingSpotRepository) {
        this.bookingRepository = bookingRepository;
        this.parkingSpotRepository = parkingSpotRepository;
    }

    public Booking createBooking(String location, VehicleType vehicleType, LocalDateTime startTime, LocalDateTime endTime) {
        List<ParkingSpot> availableSpots = parkingSpotRepository.findByIsAvailableAndLocationAndVehicleTypeAndAvailableFromBefore(true, location, vehicleType, startTime);
        if (availableSpots.isEmpty()) {
            throw new RuntimeException("No available spots for the specified location and vehicle type");
        }

        ParkingSpot spot = availableSpots.get(0); // Simplistic choice; you might want a more sophisticated approach
        double price = calculatePrice(startTime, endTime);
        Booking booking = new Booking();
        booking.setParkingSpotId(spot.getId());
        booking.setStartTime(startTime);
        booking.setEndTime(endTime);
        booking.setPrice(price);

        spot.setIsAvailable(false); // Mark as unavailable
        spot.setAvailableFrom(endTime); // Set when the spot will become available
        parkingSpotRepository.save(spot);
        return bookingRepository.save(booking);
    }

    private double calculatePrice(LocalDateTime start, LocalDateTime end) {
        long hours = Duration.between(start, end).toHours();
        return hours * 10; // Assuming $10 per hour
    }

    @Scheduled(fixedRate = 60000) // Runs every 1 minute
    public void updateAvailability() {
        LocalDateTime now = LocalDateTime.now();
        List<Booking> bookings = bookingRepository.findAll();
        for (Booking booking : bookings) {
            if (booking.getEndTime().isBefore(now)) {
                Long spotId = booking.getParkingSpotId();
                ParkingSpot spot=parkingSpotRepository.findById(spotId).get();
                spot.setIsAvailable(true);
                spot.setAvailableFrom(now); // Update the availableFrom time
                parkingSpotRepository.save(spot);
                bookingRepository.delete(booking); // Remove the booking record
            }
        }
    }
}
