package com.vehicleparking.controller;


import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import com.vehicleparking.model.Booking;
import com.vehicleparking.model.VehicleType;
import com.vehicleparking.service.BookingService;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/booking")
public class BookingController {
    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/{location}/{vehicleType}")
    public Booking createBooking(@PathVariable String location, @PathVariable VehicleType vehicleType,
                                 @RequestParam(name = "startTime", required = false)
                                 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
                                 @RequestParam(name = "startTime", required = false)
    							 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
    	if (startTime == null) {
            startTime = LocalDateTime.now();
        }
    	if(endTime==null) {
    		LocalDateTime now = LocalDateTime.now();
            endTime = now.plusDays(1);
    	}

        return bookingService.createBooking(location, vehicleType, startTime, endTime);
    }
}

