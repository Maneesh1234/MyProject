package com.vehicleparking.service;

import java.util.List;

import com.vehicleparking.model.User;

public interface UserService {
    public User saveUser(User user);
    User getUserById(Long id);
    List<User> getAllUsers();
    User updateUser(Long id, User userDetails);
    void deleteUser(Long id);
}