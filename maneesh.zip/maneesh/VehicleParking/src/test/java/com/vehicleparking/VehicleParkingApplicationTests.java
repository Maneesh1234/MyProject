package com.vehicleparking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleParkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
