package com.vehicleparking.controller;


import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.vehicleparking.model.ParkingSpot;
import com.vehicleparking.model.VehicleType;
import com.vehicleparking.service.ParkingSpotService;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/parking")
public class ParkingSpotController {
    private final ParkingSpotService service;

    public ParkingSpotController(ParkingSpotService service) {
        this.service = service;
    }

    @GetMapping
    public List<ParkingSpot> getAllSpots() {
        return service.getAllSpots();
    }

    @GetMapping("/available/{location}/{vehicleType}")
    public List<ParkingSpot> getAvailableSpotsByLocationAndVehicleType(
    		@PathVariable String location, @PathVariable VehicleType vehicleType,
            @RequestParam(name = "startTime", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime) {

        // Set a default value if startTime is null
        if (startTime == null) {
            startTime = LocalDateTime.now();
        }

        return service.getAvailableSpotsByLocationAndVehicleType(location, vehicleType, startTime);
    }

    @PostMapping
    public ParkingSpot addSpot(@RequestBody ParkingSpot spot) {
    	if(spot.getAvailableFrom()==null) 
    		spot.setAvailableFrom(LocalDateTime.now());
        return service.addSpot(spot);
    }

    @DeleteMapping("/{id}")
    public void deleteSpot(@PathVariable Long id) {
        service.deleteSpot(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ParkingSpot> updateSpot(@PathVariable Long id,@RequestBody ParkingSpot spot) {
    	ParkingSpot updatedSpot = service.updateSpot(id, spot);
    	if (updatedSpot != null) {
            return ResponseEntity.ok(updatedSpot);
        } else {
            return ResponseEntity.notFound().build();
        }
        //return service.updateSpot(id, spot);
    }
}
