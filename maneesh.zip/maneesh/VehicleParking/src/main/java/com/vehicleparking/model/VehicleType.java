package com.vehicleparking.model;

public enum VehicleType {
    CAR, MOTORCYCLE, TRUCK
}

