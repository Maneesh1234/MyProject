package com.vehicleparking.service;


import org.springframework.stereotype.Service;

import com.vehicleparking.model.ParkingSpot;
import com.vehicleparking.model.VehicleType;
import com.vehicleparking.repository.ParkingSpotRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ParkingSpotService {
    private final ParkingSpotRepository repository;

    public ParkingSpotService(ParkingSpotRepository repository) {
        this.repository = repository;
    }
    
    public ParkingSpot getSpotById(Long id) {
    	return repository.findById(id).get();
    }

    public List<ParkingSpot> getAllSpots() {
        return repository.findAll();
    }

    public List<ParkingSpot> getAvailableSpotsByLocationAndVehicleType(String location, VehicleType vehicleType, LocalDateTime startTime) {
        return repository.findByIsAvailableAndLocationAndVehicleTypeAndAvailableFromBefore(true, location, vehicleType, startTime);
    }

    public void updateSpotAvailability(ParkingSpot spot) {
        repository.save(spot);
    }

    public ParkingSpot addSpot(ParkingSpot spot) {
        return repository.save(spot);
    }

    public void deleteSpot(Long id) {
        repository.deleteById(id);
    }

    public ParkingSpot updateSpot(Long id , ParkingSpot spot) {
    	Optional<ParkingSpot> optionalParkingSpot = repository.findById(id);
        if (optionalParkingSpot.isPresent()) {
        	ParkingSpot parkingSpot  = optionalParkingSpot.get();
        	//ParkingSpot parkingSpot = repository.findById(id).get();
        	parkingSpot.setIsAvailable(spot.getIsAvailable());
        	parkingSpot.setAvailableFrom(spot.getAvailableFrom());
        	parkingSpot.setLocation(spot.getLocation());
        	parkingSpot.setVehicleType(spot.getVehicleType());
            return repository.save(parkingSpot);
        }
        return null;
    }
}
