package com.vehicleparking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vehicleparking.model.ParkingSpot;
import com.vehicleparking.model.VehicleType;

import java.time.LocalDateTime;
import java.util.List;

public interface ParkingSpotRepository extends JpaRepository<ParkingSpot, Long> {
	List<ParkingSpot> findByIsAvailableAndLocationAndVehicleTypeAndAvailableFromBefore(boolean isAvailable, String location, VehicleType vehicleType, LocalDateTime startTime);
}

